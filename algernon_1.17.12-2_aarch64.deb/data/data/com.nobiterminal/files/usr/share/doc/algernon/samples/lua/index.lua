print("Hello, Lua!")
