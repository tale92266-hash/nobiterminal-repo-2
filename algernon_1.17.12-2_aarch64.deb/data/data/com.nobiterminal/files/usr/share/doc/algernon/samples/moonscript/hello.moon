handle("/", -> print "Hello, Moonscript!")
