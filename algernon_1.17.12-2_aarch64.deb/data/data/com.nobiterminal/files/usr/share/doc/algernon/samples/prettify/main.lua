print("Hello, Lua")
