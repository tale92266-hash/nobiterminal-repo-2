#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CFITSIO::cfitsio" for configuration "Release"
set_property(TARGET CFITSIO::cfitsio APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CFITSIO::cfitsio PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libcfitsio.so.4.7.0"
  IMPORTED_SONAME_RELEASE "libcfitsio.so.10"
  )

list(APPEND _cmake_import_check_targets CFITSIO::cfitsio )
list(APPEND _cmake_import_check_files_for_CFITSIO::cfitsio "/data/data/com.nobiterminal/files/usr/lib/libcfitsio.so.4.7.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
