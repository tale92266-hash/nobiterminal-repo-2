//Copyright (c) 2006-2009 Emil Dotchevski and Reverge Studios, Inc.

//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef UUID_45CC9A82B77511DEB330FC4956D89593
#define UUID_45CC9A82B77511DEB330FC4956D89593

namespace
boost
    {
    template <class Tag,class T> class error_info;
    class exception_ptr;
    typedef error_info<struct errinfo_nested_exception_,exception_ptr> errinfo_nested_exception;
    }

#endif
