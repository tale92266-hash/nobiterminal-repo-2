// Copyright (C) 2022-2026 Exaloop Inc. <https://exaloop.io>

#pragma once

#include "codon/cir/const.h"
#include "codon/cir/dsl/nodes.h"
#include "codon/cir/flow.h"
#include "codon/cir/func.h"
#include "codon/cir/instr.h"
#include "codon/cir/module.h"
#include "codon/cir/type.h"
#include "codon/cir/value.h"
#include "codon/cir/var.h"
