# eltclsh 1.20 system files
package provide eltclsh 1.20
