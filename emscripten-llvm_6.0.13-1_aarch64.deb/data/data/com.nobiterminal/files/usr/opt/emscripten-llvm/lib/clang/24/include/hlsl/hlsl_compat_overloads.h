//===--- hlsl_compat_overloads.h - Extra HLSL overloads for intrinsics ----===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _HLSL_COMPAT_OVERLOADS_H_
#define _HLSL_COMPAT_OVERLOADS_H_

namespace hlsl {

// Note: Functions in this file are sorted alphabetically, then grouped by base
// element type, and the element types are sorted by size, then signed integer,
// unsigned integer and floating point. Keeping this ordering consistent will
// help keep this file manageable as it grows.

#define _DXC_DEPRECATED_64BIT_FN(fn)                                           \
  [[deprecated("In 202x 64 bit API lowering for " #fn " is deprecated. "       \
               "Explicitly cast parameters to 32 or 16 bit types.")]]

#define _DXC_DEPRECATED_INT_FN(fn)                                             \
  [[deprecated("In 202x int lowering for " #fn " is deprecated. "              \
               "Explicitly cast parameters to float types.")]]

#define _DXC_DEPRECATED_VEC_SCALAR_FN(fn)                                      \
  [[deprecated("In 202x mismatched vector/scalar lowering for " #fn " is "     \
               "deprecated. Explicitly cast parameters.")]]

#define _DXC_DEPRECATED_SCALAR_FN(ty1, ty2, fn)                                \
  [[deprecated("In 202x mismatched " #ty1 "/" #ty2 " lowering for " #fn " is " \
               "deprecated. Explicitly cast parameters.")]]

#define _DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(fn)                                 \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float fn(double V) { return fn((float)V); }                        \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float2 fn(double2 V) { return fn((float2)V); }                     \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float3 fn(double3 V) { return fn((float3)V); }                     \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float4 fn(double4 V) { return fn((float4)V); }

#define _DXC_COMPAT_BINARY_DOUBLE_OVERLOADS(fn)                                \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float fn(double V1, double V2) {                                   \
    return fn((float)V1, (float)V2);                                           \
  }                                                                            \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float2 fn(double2 V1, double2 V2) {                                \
    return fn((float2)V1, (float2)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float3 fn(double3 V1, double3 V2) {                                \
    return fn((float3)V1, (float3)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float4 fn(double4 V1, double4 V2) {                                \
    return fn((float4)V1, (float4)V2);                                         \
  }

#define _DXC_COMPAT_TERNARY_DOUBLE_OVERLOADS(fn)                               \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float fn(double V1, double V2, double V3) {                        \
    return fn((float)V1, (float)V2, (float)V3);                                \
  }                                                                            \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float2 fn(double2 V1, double2 V2, double2 V3) {                    \
    return fn((float2)V1, (float2)V2, (float2)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float3 fn(double3 V1, double3 V2, double3 V3) {                    \
    return fn((float3)V1, (float3)V2, (float3)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr float4 fn(double4 V1, double4 V2, double4 V3) {                    \
    return fn((float4)V1, (float4)V2, (float4)V3);                             \
  }

#define _DXC_COMPAT_UNARY_INTEGER_OVERLOADS(fn)                                \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(int V) { return fn((float)V); }                           \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(int2 V) { return fn((float2)V); }                        \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(int3 V) { return fn((float3)V); }                        \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(int4 V) { return fn((float4)V); }                        \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(uint V) { return fn((float)V); }                          \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(uint2 V) { return fn((float2)V); }                       \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(uint3 V) { return fn((float3)V); }                       \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(uint4 V) { return fn((float4)V); }                       \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(int64_t V) { return fn((float)V); }                       \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(int64_t2 V) { return fn((float2)V); }                    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(int64_t3 V) { return fn((float3)V); }                    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(int64_t4 V) { return fn((float4)V); }                    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(uint64_t V) { return fn((float)V); }                      \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(uint64_t2 V) { return fn((float2)V); }                   \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(uint64_t3 V) { return fn((float3)V); }                   \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(uint64_t4 V) { return fn((float4)V); }

#define _DXC_COMPAT_BINARY_INTEGER_OVERLOADS(fn)                               \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(int V1, int V2) { return fn((float)V1, (float)V2); }      \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(int2 V1, int2 V2) { return fn((float2)V1, (float2)V2); } \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(int3 V1, int3 V2) { return fn((float3)V1, (float3)V2); } \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(int4 V1, int4 V2) { return fn((float4)V1, (float4)V2); } \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(uint V1, uint V2) { return fn((float)V1, (float)V2); }    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(uint2 V1, uint2 V2) {                                    \
    return fn((float2)V1, (float2)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(uint3 V1, uint3 V2) {                                    \
    return fn((float3)V1, (float3)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(uint4 V1, uint4 V2) {                                    \
    return fn((float4)V1, (float4)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(int64_t V1, int64_t V2) {                                 \
    return fn((float)V1, (float)V2);                                           \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(int64_t2 V1, int64_t2 V2) {                              \
    return fn((float2)V1, (float2)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(int64_t3 V1, int64_t3 V2) {                              \
    return fn((float3)V1, (float3)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(int64_t4 V1, int64_t4 V2) {                              \
    return fn((float4)V1, (float4)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(uint64_t V1, uint64_t V2) {                               \
    return fn((float)V1, (float)V2);                                           \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(uint64_t2 V1, uint64_t2 V2) {                            \
    return fn((float2)V1, (float2)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(uint64_t3 V1, uint64_t3 V2) {                            \
    return fn((float3)V1, (float3)V2);                                         \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(uint64_t4 V1, uint64_t4 V2) {                            \
    return fn((float4)V1, (float4)V2);                                         \
  }

#define _DXC_COMPAT_TERNARY_INTEGER_OVERLOADS(fn)                              \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(int V1, int V2, int V3) {                                 \
    return fn((float)V1, (float)V2, (float)V3);                                \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(int2 V1, int2 V2, int2 V3) {                             \
    return fn((float2)V1, (float2)V2, (float2)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(int3 V1, int3 V2, int3 V3) {                             \
    return fn((float3)V1, (float3)V2, (float3)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(int4 V1, int4 V2, int4 V3) {                             \
    return fn((float4)V1, (float4)V2, (float4)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(uint V1, uint V2, uint V3) {                              \
    return fn((float)V1, (float)V2, (float)V3);                                \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(uint2 V1, uint2 V2, uint2 V3) {                          \
    return fn((float2)V1, (float2)V2, (float2)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(uint3 V1, uint3 V2, uint3 V3) {                          \
    return fn((float3)V1, (float3)V2, (float3)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(uint4 V1, uint4 V2, uint4 V3) {                          \
    return fn((float4)V1, (float4)V2, (float4)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(int64_t V1, int64_t V2, int64_t V3) {                     \
    return fn((float)V1, (float)V2, (float)V3);                                \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(int64_t2 V1, int64_t2 V2, int64_t2 V3) {                 \
    return fn((float2)V1, (float2)V2, (float2)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(int64_t3 V1, int64_t3 V2, int64_t3 V3) {                 \
    return fn((float3)V1, (float3)V2, (float3)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(int64_t4 V1, int64_t4 V2, int64_t4 V3) {                 \
    return fn((float4)V1, (float4)V2, (float4)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float fn(uint64_t V1, uint64_t V2, uint64_t V3) {                  \
    return fn((float)V1, (float)V2, (float)V3);                                \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float2 fn(uint64_t2 V1, uint64_t2 V2, uint64_t2 V3) {              \
    return fn((float2)V1, (float2)V2, (float2)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float3 fn(uint64_t3 V1, uint64_t3 V2, uint64_t3 V3) {              \
    return fn((float3)V1, (float3)V2, (float3)V3);                             \
  }                                                                            \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr float4 fn(uint64_t4 V1, uint64_t4 V2, uint64_t4 V3) {              \
    return fn((float4)V1, (float4)V2, (float4)V3);                             \
  }

#define _DXC_COMPAT_BINARY_DOUBLE_MATRIX_OVERLOADS(fn)                         \
  template <uint R, uint C>                                                    \
  _DXC_DEPRECATED_64BIT_FN(fn)                                                 \
  constexpr matrix<float, R, C> fn(matrix<double, R, C> V1,                    \
                                   matrix<double, R, C> V2) {                  \
    return fn((matrix<float, R, C>)V1, (matrix<float, R, C>)V2);               \
  }

#define _DXC_COMPAT_BINARY_INTEGER_MATRIX_OVERLOADS(fn)                        \
  template <uint R, uint C>                                                    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr matrix<float, R, C> fn(matrix<int, R, C> V1,                       \
                                   matrix<int, R, C> V2) {                     \
    return fn((matrix<float, R, C>)V1, (matrix<float, R, C>)V2);               \
  }                                                                            \
                                                                               \
  template <uint R, uint C>                                                    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr matrix<float, R, C> fn(matrix<uint, R, C> V1,                      \
                                   matrix<uint, R, C> V2) {                    \
    return fn((matrix<float, R, C>)V1, (matrix<float, R, C>)V2);               \
  }                                                                            \
                                                                               \
  template <uint R, uint C>                                                    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr matrix<float, R, C> fn(matrix<int64_t, R, C> V1,                   \
                                   matrix<int64_t, R, C> V2) {                 \
    return fn((matrix<float, R, C>)V1, (matrix<float, R, C>)V2);               \
  }                                                                            \
                                                                               \
  template <uint R, uint C>                                                    \
  _DXC_DEPRECATED_INT_FN(fn)                                                   \
  constexpr matrix<float, R, C> fn(matrix<uint64_t, R, C> V1,                  \
                                   matrix<uint64_t, R, C> V2) {                \
    return fn((matrix<float, R, C>)V1, (matrix<float, R, C>)V2);               \
  }

//===----------------------------------------------------------------------===//
// acos builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(acos)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(acos)

//===----------------------------------------------------------------------===//
// asin builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(asin)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(asin)

//===----------------------------------------------------------------------===//
// atan builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(atan)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(atan)

//===----------------------------------------------------------------------===//
// atan2 builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_BINARY_DOUBLE_OVERLOADS(atan2)
_DXC_COMPAT_BINARY_INTEGER_OVERLOADS(atan2)
_DXC_COMPAT_BINARY_DOUBLE_MATRIX_OVERLOADS(atan2)
_DXC_COMPAT_BINARY_INTEGER_MATRIX_OVERLOADS(atan2)

//===----------------------------------------------------------------------===//
// ceil builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(ceil)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(ceil)

//===----------------------------------------------------------------------===//
// clamp builtins overloads
//===----------------------------------------------------------------------===//

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(clamp)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> clamp(
    vector<T, N> p0, vector<T, N> p1, T p2) {
  return clamp(p0, p1, (vector<T, N>)p2);
}

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(clamp)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> clamp(
    vector<T, N> p0, T p1, vector<T, N> p2) {
  return clamp(p0, (vector<T, N>)p1, p2);
}

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(clamp)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> clamp(
    vector<T, N> p0, T p1, T p2) {
  return clamp(p0, (vector<T, N>)p1, (vector<T, N>)p2);
}

//===----------------------------------------------------------------------===//
// cos builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(cos)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(cos)

//===----------------------------------------------------------------------===//
// cosh builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(cosh)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(cosh)

//===----------------------------------------------------------------------===//
// degrees builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(degrees)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(degrees)

//===----------------------------------------------------------------------===//
// exp builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(exp)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(exp)

//===----------------------------------------------------------------------===//
// exp2 builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(exp2)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(exp2)

//===----------------------------------------------------------------------===//
// floor builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(floor)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(floor)

//===----------------------------------------------------------------------===//
// frac builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(frac)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(frac)

//===----------------------------------------------------------------------===//
// isfinite builtins overloads
//===----------------------------------------------------------------------===//

_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool isfinite(double V) { return isfinite((float)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool2 isfinite(double2 V) { return isfinite((float2)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool3 isfinite(double3 V) { return isfinite((float3)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool4 isfinite(double4 V) { return isfinite((float4)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool1x2 isfinite(double1x2 V) { return isfinite((float1x2)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool1x3 isfinite(double1x3 V) { return isfinite((float1x3)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool1x4 isfinite(double1x4 V) { return isfinite((float1x4)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool2x1 isfinite(double2x1 V) { return isfinite((float2x1)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool2x2 isfinite(double2x2 V) { return isfinite((float2x2)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool2x3 isfinite(double2x3 V) { return isfinite((float2x3)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool2x4 isfinite(double2x4 V) { return isfinite((float2x4)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool3x1 isfinite(double3x1 V) { return isfinite((float3x1)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool3x2 isfinite(double3x2 V) { return isfinite((float3x2)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool3x3 isfinite(double3x3 V) { return isfinite((float3x3)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool3x4 isfinite(double3x4 V) { return isfinite((float3x4)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool4x1 isfinite(double4x1 V) { return isfinite((float4x1)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool4x2 isfinite(double4x2 V) { return isfinite((float4x2)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool4x3 isfinite(double4x3 V) { return isfinite((float4x3)V); }
_DXC_DEPRECATED_64BIT_FN(isfinite)
constexpr bool4x4 isfinite(double4x4 V) { return isfinite((float4x4)V); }

//===----------------------------------------------------------------------===//
// isinf builtins overloads
//===----------------------------------------------------------------------===//

_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool isinf(double V) { return isinf((float)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool2 isinf(double2 V) { return isinf((float2)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool3 isinf(double3 V) { return isinf((float3)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool4 isinf(double4 V) { return isinf((float4)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool1x2 isinf(double1x2 V) { return isinf((float1x2)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool1x3 isinf(double1x3 V) { return isinf((float1x3)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool1x4 isinf(double1x4 V) { return isinf((float1x4)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool2x1 isinf(double2x1 V) { return isinf((float2x1)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool2x2 isinf(double2x2 V) { return isinf((float2x2)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool2x3 isinf(double2x3 V) { return isinf((float2x3)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool2x4 isinf(double2x4 V) { return isinf((float2x4)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool3x1 isinf(double3x1 V) { return isinf((float3x1)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool3x2 isinf(double3x2 V) { return isinf((float3x2)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool3x3 isinf(double3x3 V) { return isinf((float3x3)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool3x4 isinf(double3x4 V) { return isinf((float3x4)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool4x1 isinf(double4x1 V) { return isinf((float4x1)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool4x2 isinf(double4x2 V) { return isinf((float4x2)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool4x3 isinf(double4x3 V) { return isinf((float4x3)V); }
_DXC_DEPRECATED_64BIT_FN(isinf)
constexpr bool4x4 isinf(double4x4 V) { return isinf((float4x4)V); }

//===----------------------------------------------------------------------===//
// isnan builtins overloads
//===----------------------------------------------------------------------===//

_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool isnan(double V) { return isnan((float)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool2 isnan(double2 V) { return isnan((float2)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool3 isnan(double3 V) { return isnan((float3)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool4 isnan(double4 V) { return isnan((float4)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool1x2 isnan(double1x2 V) { return isnan((float1x2)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool1x3 isnan(double1x3 V) { return isnan((float1x3)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool1x4 isnan(double1x4 V) { return isnan((float1x4)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool2x1 isnan(double2x1 V) { return isnan((float2x1)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool2x2 isnan(double2x2 V) { return isnan((float2x2)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool2x3 isnan(double2x3 V) { return isnan((float2x3)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool2x4 isnan(double2x4 V) { return isnan((float2x4)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool3x1 isnan(double3x1 V) { return isnan((float3x1)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool3x2 isnan(double3x2 V) { return isnan((float3x2)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool3x3 isnan(double3x3 V) { return isnan((float3x3)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool3x4 isnan(double3x4 V) { return isnan((float3x4)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool4x1 isnan(double4x1 V) { return isnan((float4x1)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool4x2 isnan(double4x2 V) { return isnan((float4x2)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool4x3 isnan(double4x3 V) { return isnan((float4x3)V); }
_DXC_DEPRECATED_64BIT_FN(isnan)
constexpr bool4x4 isnan(double4x4 V) { return isnan((float4x4)V); }

//===----------------------------------------------------------------------===//
// lerp builtins overloads
//===----------------------------------------------------------------------===//

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(lerp)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> lerp(
    vector<T, N> x, vector<T, N> y, T s) {
  return lerp(x, y, (vector<T, N>)s);
}

_DXC_COMPAT_TERNARY_DOUBLE_OVERLOADS(lerp)
_DXC_COMPAT_TERNARY_INTEGER_OVERLOADS(lerp)

//===----------------------------------------------------------------------===//
// log builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(log)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(log)

//===----------------------------------------------------------------------===//
// log10 builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(log10)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(log10)

//===----------------------------------------------------------------------===//
// log2 builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(log2)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(log2)

//===----------------------------------------------------------------------===//
// max builtins overloads
//===----------------------------------------------------------------------===//

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(max)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> max(
    vector<T, N> p0, T p1) {
  return max(p0, (vector<T, N>)p1);
}

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(max)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> max(
    T p0, vector<T, N> p1) {
  return max((vector<T, N>)p0, p1);
}

_DXC_DEPRECATED_SCALAR_FN(float, int, max)
constexpr float max(float p0, int p1) { return max(p0, (float)p1); }

_DXC_DEPRECATED_SCALAR_FN(int, float, max)
constexpr float max(int p0, float p1) { return max((float)p0, p1); }

//===----------------------------------------------------------------------===//
// min builtins overloads
//===----------------------------------------------------------------------===//

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(min)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> min(
    vector<T, N> p0, T p1) {
  return min(p0, (vector<T, N>)p1);
}

template <typename T, uint N>
_DXC_DEPRECATED_VEC_SCALAR_FN(min)
constexpr __detail::enable_if_t<(N > 1 && N <= 4), vector<T, N>> min(
    T p0, vector<T, N> p1) {
  return min((vector<T, N>)p0, p1);
}

_DXC_DEPRECATED_SCALAR_FN(float, int, min)
constexpr float min(float p0, int p1) { return min(p0, (float)p1); }

_DXC_DEPRECATED_SCALAR_FN(int, float, min)
constexpr float min(int p0, float p1) { return min((float)p0, p1); }

//===----------------------------------------------------------------------===//
// normalize builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(normalize)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(normalize)

//===----------------------------------------------------------------------===//
// pow builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_BINARY_DOUBLE_OVERLOADS(pow)
_DXC_COMPAT_BINARY_INTEGER_OVERLOADS(pow)
_DXC_COMPAT_BINARY_DOUBLE_MATRIX_OVERLOADS(pow)
_DXC_COMPAT_BINARY_INTEGER_MATRIX_OVERLOADS(pow)

//===----------------------------------------------------------------------===//
// rsqrt builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(rsqrt)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(rsqrt)

//===----------------------------------------------------------------------===//
// round builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(round)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(round)

//===----------------------------------------------------------------------===//
// sin builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(sin)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(sin)

//===----------------------------------------------------------------------===//
// sinh builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(sinh)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(sinh)

//===----------------------------------------------------------------------===//
// sqrt builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(sqrt)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(sqrt)

//===----------------------------------------------------------------------===//
// step builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_BINARY_DOUBLE_OVERLOADS(step)
_DXC_COMPAT_BINARY_INTEGER_OVERLOADS(step)

//===----------------------------------------------------------------------===//
// tan builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(tan)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(tan)

//===----------------------------------------------------------------------===//
// tanh builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(tanh)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(tanh)

//===----------------------------------------------------------------------===//
// trunc builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(trunc)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(trunc)

//===----------------------------------------------------------------------===//
// radians builtins overloads
//===----------------------------------------------------------------------===//

_DXC_COMPAT_UNARY_DOUBLE_OVERLOADS(radians)
_DXC_COMPAT_UNARY_INTEGER_OVERLOADS(radians)

} // namespace hlsl
#endif // _HLSL_COMPAT_OVERLOADS_H_
