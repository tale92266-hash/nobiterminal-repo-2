//===----- hlsl_detail.h - HLSL definitions for intrinsics ----------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _HLSL_HLSL_DETAILS_H_
#define _HLSL_HLSL_DETAILS_H_

namespace hlsl {

namespace __detail {

constexpr double Pi = 3.14159265358979323846L;

template <typename T, typename U> struct is_same {
  static const bool value = false;
};

template <typename T> struct is_same<T, T> {
  static const bool value = true;
};

template <bool B, typename T> struct enable_if {};

template <typename T> struct enable_if<true, T> {
  using Type = T;
};

template <bool B, class T = void>
using enable_if_t = typename enable_if<B, T>::Type;

template <typename T> struct type_identity {
  using Type = T;
};

template <typename T> using type_identity_t = typename type_identity<T>::Type;

template <typename U, typename T, int R, int C>
constexpr enable_if_t<sizeof(U) == sizeof(T), matrix<U, R, C>>
bit_cast(matrix<T, R, C> M) {
  return __builtin_bit_cast(matrix<U, R, C>, M);
}

template <typename U, typename T, int N>
constexpr enable_if_t<sizeof(U) == sizeof(T), vector<U, N>>
bit_cast(vector<T, N> V) {
  return __builtin_bit_cast(vector<U, N>, V);
}

template <typename U, typename T>
constexpr enable_if_t<sizeof(U) == sizeof(T), U> bit_cast(T F) {
  return __builtin_bit_cast(U, F);
}

template <typename T> struct is_arithmetic {
  static const bool Value = __is_arithmetic(T);
};

template <typename T> struct elem_type {
  using Type = T;
};
template <typename T, int N> struct elem_type<vector<T, N>> {
  using Type = T;
};
template <typename T, int R, int C> struct elem_type<matrix<T, R, C>> {
  using Type = T;
};
template <typename T> using elem_type_t = typename elem_type<T>::Type;

struct resource_descriptor_heap_struct {
  heap_resource_info operator[](uint32_t Index) {
    return heap_resource_info{Index};
  }
};

struct sampler_descriptor_heap_struct {
  heap_sampler_info operator[](uint32_t Index) {
    return heap_sampler_info{Index};
  }
};

} // namespace __detail
} // namespace hlsl
#endif //_HLSL_HLSL_DETAILS_H_
