/************************************************************************/
/*                                                                      */
/*               Copyright 1998-2013 by Ullrich Koethe                  */
/*                                                                      */
/*    This file is part of the VIGRA computer vision library.           */
/*    The VIGRA Website is                                              */
/*        http://hci.iwr.uni-heidelberg.de/vigra/                       */
/*    Please direct questions, bug reports, and contributions to        */
/*        ullrich.koethe@iwr.uni-heidelberg.de    or                    */
/*        vigra@informatik.uni-hamburg.de                               */
/*                                                                      */
/*    Permission is hereby granted, free of charge, to any person       */
/*    obtaining a copy of this software and associated documentation    */
/*    files (the "Software"), to deal in the Software without           */
/*    restriction, including without limitation the rights to use,      */
/*    copy, modify, merge, publish, distribute, sublicense, and/or      */
/*    sell copies of the Software, and to permit persons to whom the    */
/*    Software is furnished to do so, subject to the following          */
/*    conditions:                                                       */
/*                                                                      */
/*    The above copyright notice and this permission notice shall be    */
/*    included in all copies or substantial portions of the             */
/*    Software.                                                         */
/*                                                                      */
/*    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND    */
/*    EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES   */
/*    OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND          */
/*    NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT       */
/*    HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,      */
/*    WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING      */
/*    FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR     */
/*    OTHER DEALINGS IN THE SOFTWARE.                                   */
/*                                                                      */
/************************************************************************/


#ifndef VIGRA_CONFIG_VERSION_HXX
#define VIGRA_CONFIG_VERSION_HXX

    #define VIGRA_VERSION_MAJOR 1
    #define VIGRA_VERSION_MINOR 12
    #define VIGRA_VERSION_PATCH 4

    #define VIGRA_VERSION_STRINGIFY_HELPER(x) #x
    #define VIGRA_VERSION_STRINGIFY(x) VIGRA_VERSION_STRINGIFY_HELPER(x)
    #define VIGRA_VERSION                      \
        VIGRA_VERSION_STRINGIFY(VIGRA_VERSION_MAJOR) "." \
        VIGRA_VERSION_STRINGIFY(VIGRA_VERSION_MINOR) "." \
        VIGRA_VERSION_STRINGIFY(VIGRA_VERSION_PATCH)

#endif /* VIGRA_CONFIG_VERSION_HXX */
