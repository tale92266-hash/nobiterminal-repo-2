# frozen_string_literal: true
# This file requires the implementations of ruby core's custom objects for
# serialisation/deserialisation.

require 'json/add/date'
require 'json/add/date_time'
require 'json/add/exception'
require 'json/add/range'
require 'json/add/regexp'
require 'json/add/string'
require 'json/add/struct'
require 'json/add/symbol'
require 'json/add/time'
